package com.example.mockauth.constants;

public class AppConstants {

    public static final String TYPE = "xxx";
    public static final String CLID = "45678";
    public static final String SEC = "123456789";
    public static final String BANK_ID = "abc1";
    public static final String IP_ADDRESS = "127.0.0.4";

    // Header constants
    public static final String API_KEY = "12e2435";

    // ABC structure
    public static final String VERSION = "1.0";
    public static final String PLATFORM = "Win32";
    public static final String LANGUAGE = "en-US";
    public static final int TIMEZONE = -330;
    public static final String USER_AGENT = "Mozilla/5.0 (Windows NT 6.3; Win64; x64) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.122 Safari/537.36";
    public static final boolean COOKIE_ENABLED = true;
    public static final String EXTERNAL_IP = "125.16.230.18";

    private AppConstants() {
        // Prevent instantiation
    }
}
