package com.example.mockauth.service;

import com.example.mockauth.model.LoginRequest;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

@Service
public class AuthServiceImpl implements AuthService {

    private final ObjectMapper objectMapper = new ObjectMapper();

    // ✅ Mock user credentials (You can later load from DB or config)
    private static final Map<String, String> VALID_USERS = new HashMap<>();

    static {
        VALID_USERS.put("Mona", "Mona123");
        VALID_USERS.put("<Mouna>", "Mouna123");
        VALID_USERS.put("Mounika", "Mounika123");
    }

    @Override
    public ResponseEntity<Object> login(LoginRequest request) {
        try {
            boolean isValidUser = VALID_USERS.containsKey(request.getUsername()) &&
                    VALID_USERS.get(request.getUsername()).equals(request.getPassword());

            if (isValidUser) {
                InputStream successStream = new ClassPathResource("success.json").getInputStream();
                JsonNode successJson = objectMapper.readTree(successStream);
                return ResponseEntity.ok(successJson);
            } else {
                InputStream failureStream = new ClassPathResource("failure.json").getInputStream();
                JsonNode failureJson = objectMapper.readTree(failureStream);
                return ResponseEntity.status(401).body(failureJson);
            }

        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("{\"error\": \"Unable to process request\"}");
        }
    }
}
