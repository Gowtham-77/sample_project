package com.example.mockauth.service;

import com.example.mockauth.model.LoginRequest;
import org.springframework.http.ResponseEntity;

public interface AuthService {
    ResponseEntity<Object> login(LoginRequest request);
}
