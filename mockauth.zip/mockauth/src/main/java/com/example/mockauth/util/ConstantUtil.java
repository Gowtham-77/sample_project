package com.example.mockauth.util;

import com.example.mockauth.constants.AppConstants;

import java.util.HashMap;
import java.util.Map;

public class ConstantUtil {

    private ConstantUtil() {}

    public static Map<String, Object> getStaticRequestMap(String username, String password) {
        Map<String, Object> payload = new HashMap<>();
        payload.put("type", AppConstants.TYPE);
        payload.put("clid", AppConstants.CLID);
        payload.put("sec", AppConstants.SEC);
        payload.put("bank_id", AppConstants.BANK_ID);
        payload.put("username", username);
        payload.put("password", password);
        payload.put("ip_address", AppConstants.IP_ADDRESS);

        Map<String, Object> system = Map.of(
                "Platform", AppConstants.PLATFORM,
                "Language", AppConstants.LANGUAGE,
                "Timezone", AppConstants.TIMEZONE
        );

        Map<String, Object> browser = Map.of(
                "UserAgent", AppConstants.USER_AGENT,
                "CookieEnabled", AppConstants.COOKIE_ENABLED
        );

        Map<String, Object> abp = Map.of(
                "System", system,
                "Browser", browser
        );

        Map<String, Object> abc = Map.of(
                "VERSION", AppConstants.VERSION,
                "abp", abp,
                "ExternalIP", AppConstants.EXTERNAL_IP
        );

        payload.put("abc", abc);
        return payload;
    }
}
